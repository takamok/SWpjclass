# WebserverConnection
PHP and Android code for connect to MySQL Database

For more information on the blog: http://nife0719.blog.me/221033414774 

## Contents
### - PHP Code
#### * gettest.php: Select data from MySQL Database
#### * posttest.php: Insert data into MySQL Database

### - Android Code
#### * All application source code is uploaded for connect to MySQL Database

## Example Application
![ExampleApplication]

[ExampleApplication]: Example_Application.gif
