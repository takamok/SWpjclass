package com.example.myapplication;

import android.content.CursorLoader;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.media.ExifInterface;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    public TextView mView;
    private static int PICK_IMAGE_REQUEST = 1;
    ImageView imgView;
    static final String TAG = "MainActivity";

    Button ImageButton;
    Button MapButton;
    Button ReviewButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent = new Intent(getApplicationContext(), LoadingActivity.class);
        startActivity(intent);

        MapButton = findViewById(R.id.MapButton);
        ReviewButton = findViewById(R.id.ReviewButton);

        MapButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MapActivity.class);
                startActivity(intent);
            }
        });

        ReviewButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ReViewActivity.class);
                startActivity(intent);
            }
        });
    }

    public void loadImagefromGallery(View view) {
        //Intent 생성
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT); //ACTION_PIC과 차이점?
        intent.setType("image/*"); //이미지만 보이게
        //Intent 시작 - 갤러리앱을 열어서 원하는 이미지를 선택할 수 있다.
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    //이미지 선택작업을 후의 결과 처리
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try {
            //이미지를 하나 골랐을때
            if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && null != data) {
                //data에서 절대경로로 이미지를 가져옴
                Uri uri = data.getData();
                Log.d("Real path is : ", getImagePath(data.getData()));



            } else {
                Toast.makeText(this, "취소 되었습니다.", Toast.LENGTH_LONG).show();
            }

        } catch (Exception e) {
            Toast.makeText(this, "Oops! 로딩에 오류가 있습니다.", Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }

    }
    public String getImagePath(Uri data){
/* data
 정확히 파악은 하지 못했지만 리턴된 data의 결과에서 커서를 통해 실질적인 저장경로를 뽑아오는거
 같음.
 data.getPath()도 존재하지만 실질적인 경로가 아니여서 이 메소드를 활용함.
 */
        String[] proj = { MediaStore.Images.Media.DATA };
        CursorLoader loader = new CursorLoader(this, data, proj, null, null, null);
        Cursor cursor = loader.loadInBackground();
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        String result = cursor.getString(column_index);
        cursor.close();

        try {
            ExifInterface exif = new ExifInterface(result);
            showExif(exif);
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error!", Toast.LENGTH_LONG).show();
        }

        return result;


    }


    public void showExif(ExifInterface exif) {



        String myAttribute = "[Exif information] \n\n";


        Log.d("EXIF", "exif TAG_APERTURE:" + exif.getAttribute(ExifInterface.TAG_APERTURE));
        Log.d("EXIF", "exif TAG_DATETIME:" + exif.getAttribute(ExifInterface.TAG_DATETIME));
        Log.d("EXIF", "exif TAG_EXPOSURE_TIME:" + exif.getAttribute(ExifInterface.TAG_EXPOSURE_TIME));
        Log.d("EXIF", "exif TAG_FLASH:" + exif.getAttribute(ExifInterface.TAG_FLASH));
        Log.d("EXIF", "exif TAG_FOCAL_LENGTH:" + exif.getAttribute(ExifInterface.TAG_FOCAL_LENGTH));
        Log.d("EXIF", "exif TAG_GPS_ALTITUDE:" + exif.getAttribute(ExifInterface.TAG_GPS_ALTITUDE));
        Log.d("EXIF", "exif TAG_GPS_ALTITUDE_REF:" + exif.getAttribute(ExifInterface.TAG_GPS_ALTITUDE_REF));
        Log.d("EXIF", "exif TAG_GPS_DATESTAMP:" + exif.getAttribute(ExifInterface.TAG_GPS_DATESTAMP));
        Log.d("EXIF", "exif TAG_GPS_LATITUDE:" + exif.getAttribute(ExifInterface.TAG_GPS_LATITUDE));
        Log.d("EXIF", "exif TAG_GPS_LATITUDE_REF:" + exif.getAttribute(ExifInterface.TAG_GPS_LATITUDE_REF));
        Log.d("EXIF", "exif TAG_GPS_LONGITUDE:" + exif.getAttribute(ExifInterface.TAG_GPS_LONGITUDE));
        Log.d("EXIF", "exif TAG_GPS_LONGITUDE_REF:" + exif.getAttribute(ExifInterface.TAG_GPS_LONGITUDE_REF));
        Log.d("EXIF", "exif TAG_GPS_PROCESSING_METHOD:" + exif.getAttribute(ExifInterface.TAG_GPS_PROCESSING_METHOD));
        Log.d("EXIF", "exif TAG_GPS_TIMESTAMP:" + exif.getAttribute(ExifInterface.TAG_GPS_TIMESTAMP));
        Log.d("EXIF", "exif TAG_IMAGE_LENGTH:" + exif.getAttribute(ExifInterface.TAG_IMAGE_LENGTH ));
        Log.d("EXIF", "exif TAG_IMAGE_WIDTH:" + exif.getAttribute(ExifInterface.TAG_IMAGE_WIDTH ));
        Log.d("EXIF", "exif TAG_ISO:" + exif.getAttribute(ExifInterface.TAG_ISO));
        Log.d("EXIF", "exif TAG_MAKE:" + exif.getAttribute(ExifInterface.TAG_MAKE));
        Log.d("EXIF", "exif TAG_MODEL:" + exif.getAttribute(ExifInterface.TAG_MODEL));
        Log.d("EXIF", "exif TAG_ORIENTATION:" + exif.getAttribute(ExifInterface.TAG_ORIENTATION));
        Log.d("EXIF", "exif TAG_WHITE_BALANCE:" + exif.getAttribute(ExifInterface.TAG_WHITE_BALANCE));
/*
        myAttribute += getTagString(ExifInterface.TAG_DATETIME, exif);
        myAttribute += getTagString(ExifInterface.TAG_FLASH, exif);
        myAttribute += getTagString(ExifInterface.TAG_GPS_LATITUDE,
                exif);
        myAttribute += getTagString(
                ExifInterface.TAG_GPS_LATITUDE_REF, exif);
        myAttribute += getTagString(ExifInterface.TAG_GPS_LONGITUDE,
                exif);
        myAttribute += getTagString(
                ExifInterface.TAG_GPS_LONGITUDE_REF, exif);
        myAttribute += getTagString(ExifInterface.TAG_IMAGE_LENGTH,
                exif);
        myAttribute += getTagString(ExifInterface.TAG_IMAGE_WIDTH,
                exif);
        myAttribute += getTagString(ExifInterface.TAG_MAKE, exif);
        myAttribute += getTagString(ExifInterface.TAG_MODEL, exif);
        myAttribute += getTagString(ExifInterface.TAG_ORIENTATION,
                exif);
        myAttribute += getTagString(ExifInterface.TAG_WHITE_BALANCE,
                exif);


        mView.setText(myAttribute);
*/
    }



    private String getTagString(String tag, ExifInterface exif) {

        return (tag + " : " + exif.getAttribute(tag) + "\n");

    }






}
